document.addEventListener("DOMContentLoaded", async () => {
  const treeContainer = document.getElementById("treeContainer");
  const favoritesContainer = document.getElementById("favoritesContainer");
  const addGuestsBtn = document.getElementById("addGuestsBtn");
  const copyGuestsBtn = document.getElementById("copyGuestsBtn");
  const openOptionsBtn = document.getElementById("openOptionsBtn");
  const statusMessage = document.getElementById("statusMessage");

  const storage = await chrome.storage.local.get("groupTree");
  const groupTree = storage.groupTree || getDefaultData();

  const favoriteGroups = getFavoriteGroups(groupTree);
  renderTree(favoriteGroups, favoritesContainer, false);
  renderTree(groupTree, treeContainer, false);

  openOptionsBtn.addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });

  addGuestsBtn.addEventListener("click", async () => {
    const selectedEmails = getSelectedEmails();
    if (selectedEmails.length === 0) {
      showStatus("グループまたはメンバーを選択してください", "error");
      return;
    }

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url.includes("calendar.google.com")) {
      showStatus("Googleカレンダーのページで実行してください", "error");
      return;
    }

    chrome.tabs.sendMessage(tab.id, { action: "INSERT_GUESTS", emails: selectedEmails }, (response) => {
      if (chrome.runtime.lastError || !response || !response.success) {
        showStatus("カレンダーの編集ダイアログが開かれているか確認してください", "error");
      } else {
        showStatus(`${response.count} 件のゲストを設定しました`, "success");
        setTimeout(() => window.close(), 1200);
      }
    });
  });

  copyGuestsBtn.addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url.includes("calendar.google.com")) {
      showStatus("Googleカレンダーのページで実行してください", "error");
      return;
    }

    chrome.tabs.sendMessage(tab.id, { action: "COPY_GUESTS" }, async (response) => {
      if (chrome.runtime.lastError || !response || !response.emails) {
        showStatus("ゲストアドレスの取得に失敗しました", "error");
        return;
      }

      if (response.emails.length === 0) {
        showStatus("設定済みのゲストが見つかりませんでした", "error");
        return;
      }

      const textToCopy = response.emails.map(email => formatRegisteredGuest(email, groupTree)).join(", ");
      try {
        await navigator.clipboard.writeText(textToCopy);
        showStatus(`${response.emails.length} 件のアドレスをコピーしました`, "success");
      } catch (err) {
        showStatus("クリップボードへのコピーに失敗しました", "error");
      }
    });
  });

  function showStatus(msg, type) {
    statusMessage.textContent = msg;
    statusMessage.className = `status-message ${type}`;
  }
});

function getDefaultData() {
  return [
    {
      id: "node_1",
      name: "開発部",
      emails: [],
      children: [
        { id: "node_2", name: "フロントエンドチーム", emails: ["alice@example.com", "bob@example.com"], children: [] },
        { id: "node_3", name: "バックエンドチーム", emails: ["charlie@example.com", "dave@example.com"], children: [] }
      ]
    },
    {
      id: "node_4",
      name: "営業部",
      emails: ["eve@example.com", "frank@example.com"],
      children: []
    }
  ];
}

function renderTree(nodes, container, expandedInitially = false) {
  container.innerHTML = "";
  const ul = document.createElement("ul");
  ul.className = "tree-root";
  nodes.forEach(node => ul.appendChild(createTreeNodeElement(node, expandedInitially)));
  container.appendChild(ul);

  container.addEventListener("change", (event) => {
    const target = event.target;
    if (target.matches(".group-checkbox")) {
      const li = target.closest("li");
      li.querySelectorAll(".group-checkbox, .email-checkbox").forEach(checkbox => {
        checkbox.checked = target.checked;
        checkbox.indeterminate = false;
      });
      syncAncestorGroups(li.parentElement?.closest("li") || null);
    } else if (target.matches(".email-checkbox")) {
      syncAncestorGroups(target.closest("li"));
    }
  });

  container.addEventListener("click", (event) => {
    if (event.target.classList.contains("toggle-btn")) {
      const childUl = event.target.closest("li").querySelector(":scope > ul");
      if (childUl) {
        childUl.classList.toggle("collapsed");
        event.target.textContent = childUl.classList.contains("collapsed") ? "▶" : "▼";
      }
    }
  });
}

function syncAncestorGroups(startLi) {
  let li = startLi;
  while (li) {
    const groupCheckbox = li.querySelector(":scope > .tree-row .group-checkbox");
    if (groupCheckbox) {
      const emailCheckboxes = Array.from(li.querySelectorAll(".email-checkbox"));
      const checkedCount = emailCheckboxes.filter(checkbox => checkbox.checked).length;
      groupCheckbox.checked = emailCheckboxes.length > 0 && checkedCount === emailCheckboxes.length;
      groupCheckbox.indeterminate = checkedCount > 0 && checkedCount < emailCheckboxes.length;
    }
    li = li.parentElement?.closest("li") || null;
  }
}

function createTreeNodeElement(node, expandedInitially = false) {
  const li = document.createElement("li");
  const row = document.createElement("div");
  row.className = "tree-row";

  const emails = Array.isArray(node.emails) ? node.emails : [];
  const children = Array.isArray(node.children) ? node.children : [];
  const hasTreeChildren = emails.length > 0 || children.length > 0;

  if (hasTreeChildren) {
    const toggleBtn = document.createElement("span");
    toggleBtn.className = "toggle-btn";
    toggleBtn.textContent = expandedInitially ? "▼" : "▶";
    row.appendChild(toggleBtn);
  } else {
    const spacer = document.createElement("span");
    spacer.className = "toggle-spacer";
    row.appendChild(spacer);
  }

  const groupLabel = document.createElement("label");
  const groupCheckbox = document.createElement("input");
  groupCheckbox.type = "checkbox";
  groupCheckbox.className = "group-checkbox";
  groupLabel.appendChild(groupCheckbox);
  const groupIcon = document.createElement("span");
  groupIcon.className = "group-icon";
  groupIcon.setAttribute("aria-hidden", "true");
  groupIcon.textContent = "📁";
  groupLabel.appendChild(groupIcon);
  groupLabel.appendChild(document.createTextNode(` ${node.name}`));
  row.appendChild(groupLabel);
  li.appendChild(row);

  // グループに直接登録されたメールアドレスも、ツリー配下の子要素として表示する。
  if (hasTreeChildren) {
    const ul = document.createElement("ul");
    ul.className = expandedInitially ? "" : "collapsed";
    emails.forEach(email => ul.appendChild(createEmailTreeNode(email)));
    children.forEach(child => ul.appendChild(createTreeNodeElement(child, expandedInitially)));
    li.appendChild(ul);
  }

  return li;
}

function createEmailTreeNode(entry) {
  const member = parseMemberEntry(entry);
  const email = member.email;
  const displayName = member.name || email;
  const copyValue = member.name ? formatNamedMember(member.name, email) : email;
  const li = document.createElement("li");
  li.className = "email-tree-node";

  const row = document.createElement("div");
  row.className = "tree-row email-row";

  const spacer = document.createElement("span");
  spacer.className = "toggle-spacer";
  row.appendChild(spacer);

  const emailLabel = document.createElement("label");
  const emailCheckbox = document.createElement("input");
  emailCheckbox.type = "checkbox";
  emailCheckbox.className = "email-checkbox";
  emailCheckbox.dataset.email = email;
  emailCheckbox.dataset.copyValue = copyValue;
  emailLabel.appendChild(emailCheckbox);
  emailLabel.appendChild(document.createTextNode(` ${displayName}`));
  if (member.name) emailLabel.title = email;
  row.appendChild(emailLabel);

  li.appendChild(row);
  return li;
}

function parseMemberEntry(value) {
  const entry = String(value || "").trim();
  const match = entry.match(/^(?:"((?:\\.|[^"\\])*)"|([^<>"]+?))\s*<([^<>]+)>$/);
  if (match) {
    const name = match[1] !== undefined ? unescapeQuotedName(match[1]).trim() : match[2].trim();
    return { name, email: match[3].trim() };
  }
  return { name: "", email: entry };
}

function unescapeQuotedName(name) {
  return name.replace(/\\(["\\])/g, "$1");
}

function formatNamedMember(name, email) {
  const escapedName = String(name).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  return `"${escapedName}"<${email}>`;
}

function formatRegisteredGuest(email, tree) {
  const target = String(email || "").trim().toLowerCase();
  let formatted = email;
  function visit(nodes) {
    for (const node of nodes || []) {
      for (const entry of Array.isArray(node.emails) ? node.emails : []) {
        const member = parseMemberEntry(entry);
        if (member.email.toLowerCase() === target && member.name) {
          formatted = formatNamedMember(member.name, member.email);
          return true;
        }
      }
      if (visit(node.children)) return true;
    }
    return false;
  }
  visit(tree);
  return formatted;
}

function getSelectedEmails() {
  const selected = new Set();
  document.querySelectorAll("#treeContainer .email-checkbox:checked, #favoritesContainer .email-checkbox:checked").forEach(checkbox => {
    if (checkbox.dataset.email) selected.add(checkbox.dataset.email);
  });
  return Array.from(selected);
}


function getFavoriteGroups(nodes) {
  const favorites = [];
  function visit(items) {
    (items || []).forEach(node => {
      if (node.favorite === true) favorites.push(node);
      visit(node.children);
    });
  }
  visit(nodes);
  return favorites;
}
